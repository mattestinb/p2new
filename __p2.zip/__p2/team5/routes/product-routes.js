const express = require('express');
const router = express.Router();
const { Product } = require('../models'); 
const ProductController = require('../controllers/productController');

// route to display products
router.get('/products', async (req, res) => {
  const products = await Product.findAll();
  res.render('products', { products }); 
});

// get the product of selected id page
router.get('/:id', async (req, res) => {
  try {
    const productData = await Product.findByPk(req.params.id, {
      include: [
        {
          model: Product,
          attributes: ['name'],
          
        },
      ],
    });

    const product = productData.get({ plain: true });

    res.render('product', {
      ...product,
      logged_in: req.session.logged_in
    });
  } catch (err) {
    res.status(500).json(err);
  }
});

//post product @mb
router.post('/', async (req,res) => {
  try {
    const productData = await Product.create(req.body);
    res.status(200).json(productData);
  }catch (err) {
    res.status(400).json(err);
  }
});

// update product by ID @MB
// let productPathId = this.toString(this.product.id);
router.put('products/:id', async (req, res) => {
  Product.update(
    {
      name: req.body.name,
      description: req.body.description,
      price: req.body.price,
    },
    {
      where: {
        id: req.params.id,
      },
    }
  )
    .then((updatedProduct) => {
      res.json(updatedProduct);
    })
    .catch((err) => {
      console.log(err);
      res.json(err);
    });
});


// delete product by ID @MB
router.delete('products/:id', async (req, res) => {
  try {
    const productData = await Product.destroy({
      where: {
        id: req.params.id,
      },
    });

    if (!productData) {
      res.status(404).json({ message: 'No product listing found with that id!' });
      return;
    }
    res.status(200).json(productData);
  } catch (err) {
    res.status(500).json(err);
  }
});

//is causing an error
// router.get('/products/:id', ProductController.getProduct);

module.exports = router;
