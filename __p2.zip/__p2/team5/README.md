
# PostUp
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Description
Interactive Full-Stack Application

## Table of Contents:

[Installation](#installation)

[Usage](#usage)

[License](#license)

[Contributing](#contributing)

[Tests](#tests)

[Questions](#contact-information)

## Installation
Open root folder in the terminal and input npm install to install dependencies.

## Usage
-

## License
MIT

## Contributing
DerekDang05, Iamshaylajade, Matt Estin.

## Tests
None

## Contact Information
Github Username: 

Contact E-mail: vincepeo@yahoo.com
